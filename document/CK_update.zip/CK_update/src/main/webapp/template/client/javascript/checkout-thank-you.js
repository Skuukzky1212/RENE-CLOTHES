// hide header
const hide_header = document.querySelector('.header');
hide_header.style.display = 'none';