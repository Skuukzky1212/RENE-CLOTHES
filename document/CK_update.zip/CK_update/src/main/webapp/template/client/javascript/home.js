// header slider  
$(document).ready(function() {
    $(".slider__container-img").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        draggable: true,
        prevArrow: false,
        nextArrow:false,
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true,
        pauseOnHover: false,
        pauseOnDotsHover: false,
        pauseOnFocus: false,
        // fade: true,
        // cssEase: 'linear',
        responsive: [
            {
                breakpoint: 1025,
                settings: {
                    slidesToShow: 1,
                },
            },
            {

                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    infinite: false,
                    draggable: true,
                },
            },
        ],
    });
});


// best seller banner
$(document).ready(function() {
    $(".container__product-home-banner-img-slider").slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        draggable: false,
        prevArrow:"<button type='button' class='slick-prev pull-left'><i class='ti-arrow-left' aria-hidden='true'></i></button>",
        nextArrow:"<button type='button' class='slick-next pull-right'><i class='ti-arrow-right' aria-hidden='true'></i></button>",
        responsive: [
            {
                breakpoint: 1025,
                settings: {
                    slidesToShow: 3,
                },
            },
            {

                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    infinite: false,
                    draggable: true,
                },
            },
        ],
    });
});

// fill icon - add to wishlist
const addWishlistBtns = document.querySelectorAll('.main-product-item__action')
for (let addWishlistBtn of addWishlistBtns) {
    addWishlistBtn.addEventListener('click', function() {
        if (addWishlistBtn.classList.contains('main-product-item__like--liked')) {
            addWishlistBtn.classList.remove('main-product-item__like--liked')

        }
        else {
            addWishlistBtn.classList.add('main-product-item__like--liked');
        }
    });
}
