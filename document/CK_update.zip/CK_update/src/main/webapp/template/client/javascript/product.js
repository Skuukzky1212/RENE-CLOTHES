//-----Filter modal-----
    const filterModalBtn = document.querySelector('.container__filter');
    const openFilterModal = document.querySelector('.filter__modal-overlay');
    const filterModalContainer = document.querySelector('.filter__modal');
   
   // open filter Modal 
   filterModalBtn.addEventListener('click', function() {
       openFilterModal.classList.toggle('open');
       disableScroll.classList.toggle('disableScrolling');
   });
   
   // close filter Modal when click into overlay class
   openFilterModal.addEventListener('click', function() {
       openFilterModal.classList.remove('open');
       disableScroll.classList.remove('disableScrolling');
   });
    
   // Stop Propagation when click into overlay class
   filterModalContainer.addEventListener('click', function(e) {
       e.stopPropagation();
   });

// close btn
for ( closeSideModal of closeSideModals) {
    closeSideModal.addEventListener('click', function() {
        openFilterModal.classList.remove('open');
        disableScroll.classList.remove('disableScrolling');
    })
}

// fill icon - add to wishlist
const addWishlistBtns = document.querySelectorAll('.main-product-item__action')
for (let addWishlistBtn of addWishlistBtns) {
    addWishlistBtn.addEventListener('click', function() {
        if (addWishlistBtn.classList.contains('main-product-item__like--liked')) {
            addWishlistBtn.classList.remove('main-product-item__like--liked')

        }
        else {
            addWishlistBtn.classList.add('main-product-item__like--liked');
        }
    });
}
