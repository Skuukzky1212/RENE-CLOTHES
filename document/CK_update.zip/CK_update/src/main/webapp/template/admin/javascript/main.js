// Handle sidebar
const sidebarItems = document.querySelectorAll('.sidebar__item-link');

if (sidebarItems) {
    sidebarItems.forEach((sidebarItem, _index) => {
        sidebarItem.onclick = (e) => {
            const sidebarSub = sidebarItem.nextElementSibling;

            if (sidebarSub) {
                e.preventDefault();
                if (sidebarSub.style.maxHeight) {
                    sidebarSub.style.maxHeight = null;
                } else {
                    sidebarSub.style.maxHeight = `${sidebarSub.scrollHeight}px`;
                }
            }
        };
    });
}