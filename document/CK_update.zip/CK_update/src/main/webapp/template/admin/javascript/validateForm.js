const formUser = document.querySelector(".form-user");

const checkValidation = (formElement) => {
    const formControls = formElement.querySelectorAll(".form-control");

    if (formControls) {
        formControls.forEach((formControl, index) => {
            formControl.addEventListener("change", (e) => {
                const {value, name} = e.target;

                if (value) {

                }
            })
        })
    }
}