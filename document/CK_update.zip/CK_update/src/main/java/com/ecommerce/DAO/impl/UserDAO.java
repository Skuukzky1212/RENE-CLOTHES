package com.ecommerce.DAO.impl;

import com.ecommerce.DAO.IUserDAO;
import com.ecommerce.mapper.UserMapper;
import com.ecommerce.model.UserModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public class UserDAO extends AbstractDAO<UserModel> implements IUserDAO {

    @Override
    public List<UserModel> getAll(Pageble pageble) {
        StringBuilder query = new StringBuilder("SELECT * FROM Users");
        if (pageble.getSorter() != null) {
            query.append(" ORDER BY " + pageble.getSorter().getSortBy() + " "+ pageble.getSorter().getSortType() +"");
        }

        if (pageble.getOffset() != null && pageble.getLimit() != null) {
            query.append(" OFFSET " + pageble.getOffset() + " ROWS FETCH NEXT "+ pageble.getLimit() +" ROWS ONLY");
        }
        return query(query.toString(), new UserMapper());
    }

    @Override
    public UserModel getOneById(Long id) {
        String query = "SELECT * FROM Users WHERE id = ?";
        List<UserModel> users = query(query, new UserMapper(), id);
        return users.isEmpty() ? null : users.get(0);
    }

    @Override
    public Long create(UserModel user) {
        String query = "INSERT INTO Users(username, password, full_name, status, role, created_at) VALUES(?,?,?,?,?,?)";
        return insert(query, user.getUserName(), user.getPassword(),
                user.getFullName(), user.getStatus(), user.getRole(), user.getCreatedAt());
    }

    @Override
    public void update(UserModel updateUser) {
        String query = "UPDATE Users SET password = ?, full_name = ?, status = ?, role = ?, created_at = ?, updated_at = ? WHERE id = ?";
        update(query, updateUser.getPassword(),
                updateUser.getFullName(), updateUser.getStatus(), updateUser.getRole(),
                updateUser.getCreatedAt(), updateUser.getUpdatedAt(), updateUser.getId());
    }

    @Override
    public void delete(long id) {
        String query = "DELETE FROM Users WHERE id = ?";
        update(query, id);
    }

    @Override
    public int getTotalItem() {
        String query = "SELECT count(*) FROM Users";
        return count(query);
    }

    @Override
    public UserModel login(String userName, String password, Integer status) {
        String query = "SELECT * FROM Users WHERE username = ? AND password = ? AND status = ?";
        List<UserModel> users = query(query, new UserMapper(), userName, password, status);
        return users.isEmpty() ? null : users.get(0);
    }
}
