package com.ecommerce.DAO.impl;

import com.ecommerce.DAO.GenericDAO;
import com.ecommerce.DAO.ICategoryDAO;
import com.ecommerce.mapper.CategoryMapper;
import com.ecommerce.mapper.UserMapper;
import com.ecommerce.model.CategoryModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public class CategoryDAO extends AbstractDAO<CategoryModel> implements ICategoryDAO {
    @Override
    public List<CategoryModel> getAll(Pageble pageble) {
        StringBuilder query = new StringBuilder("SELECT * FROM Categories");
        if (pageble.getSorter() != null) {
            query.append(" ORDER BY " + pageble.getSorter().getSortBy() + " "+ pageble.getSorter().getSortType() +"");
        }

        if (pageble.getOffset() != null && pageble.getLimit() != null) {
            query.append(" OFFSET " + pageble.getOffset() + " ROWS FETCH NEXT "+ pageble.getLimit() +" ROWS ONLY");
        }
        return query(query.toString(), new CategoryMapper());
    }

    @Override
    public int getTotalItem() {
        String query = "SELECT count(*) FROM Categories";
        return count(query);
    }
}
