package com.ecommerce.controller.admin;

import com.ecommerce.constant.SystemConstant;
import com.ecommerce.model.CategoryModel;
import com.ecommerce.pagination.PageRequest;
import com.ecommerce.pagination.Pageble;
import com.ecommerce.service.ICategoryService;
import com.ecommerce.sort.Sorter;
import com.ecommerce.utils.FormUtil;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = {"/admin/category"})
public class CategoryController extends HttpServlet {

    @Inject
    private ICategoryService categoryService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CategoryModel categoryModel = FormUtil.toModel(CategoryModel.class, req);
        Pageble pageble = new PageRequest(categoryModel.getPage(), categoryModel.getPerPage(), new Sorter(categoryModel.getSortBy(), categoryModel.getSortType()));

        categoryModel.setResult(categoryService.getAll(pageble));
        categoryModel.setTotalItem(categoryService.getTotalItem());
        categoryModel.setTotalPage((int) Math.ceil((double) categoryModel.getTotalItem() / categoryModel.getPerPage()));

        req.setAttribute(SystemConstant.MODEL, categoryModel);
        RequestDispatcher rd = req.getRequestDispatcher("/views/admin/category/list.jsp");
        rd.forward(req, resp);
    }
}
