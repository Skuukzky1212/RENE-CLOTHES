package com.ecommerce.constant;

public class SystemConstant {
    public static final String MODEL = "model";
    public static final String ADMIN = "admin";
    public static final String USER = "user";
    public static final String LIST = "list";
    public static final String EDIT = "edit";
}
