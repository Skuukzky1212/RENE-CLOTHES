package com.ecommerce.controller.admin;

import com.ecommerce.constant.SystemConstant;
import com.ecommerce.model.UserModel;
import com.ecommerce.pagination.PageRequest;
import com.ecommerce.pagination.Pageble;
import com.ecommerce.service.IUserService;
import com.ecommerce.sort.Sorter;
import com.ecommerce.utils.FormUtil;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = {"/admin/user"})
public class UserController extends HttpServlet {

    @Inject
    private IUserService userService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserModel userModel = FormUtil.toModel(UserModel.class, req);
        String view = "";

        if (userModel.getType().equals(SystemConstant.LIST)) {
            Pageble pageble = new PageRequest(userModel.getPage(), userModel.getPerPage(),
                    new Sorter(userModel.getSortBy(), userModel.getSortType()));

            userModel.setResult(userService.getAll(pageble));
            userModel.setTotalItem(userService.getTotalItem());
            userModel.setTotalPage((int) Math.ceil((double) userModel.getTotalItem() / userModel.getPerPage()));

            view = "/views/admin/user/list.jsp";
        } else if (userModel.getType().equals(SystemConstant.EDIT)) {
            if (userModel.getId() != null) {
                userModel = userService.getOneById(userModel.getId());
            } else {

            }
            view = "/views/admin/user/edit.jsp";
        }

        req.setAttribute(SystemConstant.MODEL, userModel);
        RequestDispatcher rd = req.getRequestDispatcher(view);
        rd.forward(req, resp);
    }
}
