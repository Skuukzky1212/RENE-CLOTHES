package com.ecommerce.DAO;

import com.ecommerce.model.UserModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public interface IUserDAO extends GenericDAO<UserModel> {
    List<UserModel> getAll(Pageble pageble);
    UserModel getOneById(Long id);
    Long create(UserModel user);
    void update(UserModel updateUser);
    void delete(long id);
    int getTotalItem();
    UserModel login(String userName, String password, Integer status);
}
