package com.ecommerce.mapper;

import com.ecommerce.model.UserModel;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserMapper implements RowMapper<UserModel> {
    @Override
    public UserModel mapRow(ResultSet resultSet) {
        try {
            UserModel user = new UserModel();
            user.setId(resultSet.getLong("id"));
            user.setUserName(resultSet.getString("username"));
            user.setPassword(resultSet.getString("password"));
            user.setFullName(resultSet.getString("full_name"));
            user.setStatus(resultSet.getInt("status"));
            user.setRole(resultSet.getString("role"));
            user.setCreatedAt(resultSet.getTimestamp("created_at"));

            if (resultSet.getTimestamp("updated_at") != null) {
                user.setUpdatedAt(resultSet.getTimestamp("updated_at"));
            }
            return user;
        } catch (SQLException e) {
            return null;
        }
    }
}
