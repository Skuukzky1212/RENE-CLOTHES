package com.ecommerce.service;

import com.ecommerce.model.UserModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public interface IUserService {
    List<UserModel> getAll(Pageble pageble);
    UserModel create(UserModel user);
    UserModel update(UserModel user);
    void delete(long[] ids);
    int getTotalItem();
    UserModel login(String userName, String password, Integer status);
    UserModel getOneById(long id);
}
