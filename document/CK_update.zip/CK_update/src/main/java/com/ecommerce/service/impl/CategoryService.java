package com.ecommerce.service.impl;

import com.ecommerce.DAO.ICategoryDAO;
import com.ecommerce.model.CategoryModel;
import com.ecommerce.pagination.Pageble;
import com.ecommerce.service.ICategoryService;

import javax.inject.Inject;
import java.util.List;

public class CategoryService implements ICategoryService {

    @Inject
    private ICategoryDAO categoryDAO;

    @Override
    public List<CategoryModel> getAll(Pageble pageble) {
        return categoryDAO.getAll(pageble);
    }

    @Override
    public int getTotalItem() {
        return categoryDAO.getTotalItem();
    }
}
