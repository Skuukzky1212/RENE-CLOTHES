package com.ecommerce.service.impl;

import com.ecommerce.DAO.IUserDAO;
import com.ecommerce.model.UserModel;
import com.ecommerce.pagination.Pageble;
import com.ecommerce.service.IUserService;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.util.List;

public class UserService implements IUserService {
//    private IUserDAO userDAO;
//
//    public UserService() {
//        userDAO = new UserDAO();
//    }

    @Inject
    private IUserDAO userDAO;

    @Override
    public List<UserModel> getAll(Pageble pageble) {
        return userDAO.getAll(pageble);
    }

    @Override
    public UserModel create(UserModel user) {
        user.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        Long userId = userDAO.create(user);
        return userDAO.getOneById(userId);
    }

    @Override
    public UserModel update(UserModel user) {
        UserModel oldUser = userDAO.getOneById(user.getId());
        user.setCreatedAt(oldUser.getCreatedAt());
        user.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        userDAO.update(user);
        return userDAO.getOneById(user.getId());
    }

    @Override
    public void delete(long[] ids) {
        for (long id: ids) {
            userDAO.delete(id);
        }
    }

    @Override
    public int getTotalItem() {
        return userDAO.getTotalItem();
    }

    @Override
    public UserModel login(String userName, String password, Integer status) {
        return userDAO.login(userName, password, status);
    }

    @Override
    public UserModel getOneById(long id) {
        return userDAO.getOneById(id);
    }
}
