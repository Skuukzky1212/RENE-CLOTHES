package com.ecommerce.DAO;

import com.ecommerce.mapper.RowMapper;

import java.util.List;

public interface GenericDAO<T> {
    <T> List<T> query(String query, RowMapper<T> rowMapper, Object...parameters);
    void update(String query, Object...parameters);
    Long insert(String query, Object...parameters);
    int count(String query, Object...parameters);
}
