package com.ecommerce.service;

import com.ecommerce.model.CategoryModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public interface ICategoryService {
    List<CategoryModel> getAll(Pageble pageble);
    int getTotalItem();
}
