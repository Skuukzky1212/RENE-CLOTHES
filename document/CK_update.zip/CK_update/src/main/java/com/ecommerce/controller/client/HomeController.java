package com.ecommerce.controller.client;

import com.ecommerce.constant.SystemConstant;
import com.ecommerce.model.UserModel;
import com.ecommerce.service.IUserService;
import com.ecommerce.utils.FormUtil;
import com.ecommerce.utils.SessionUtil;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ResourceBundle;

@WebServlet(urlPatterns = {"/home", "/login", "/logout"})
public class HomeController extends HttpServlet {

    ResourceBundle resourceBundle = ResourceBundle.getBundle("message");

    @Inject
    private IUserService userService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String loginMsg = req.getParameter("message");
        String action = req.getParameter("action");

        if (loginMsg != null) {
            req.setAttribute("LOGIN_MSG", resourceBundle.getString(loginMsg));
        }

        if (action != null && action.equals("logout")) {
            SessionUtil.getInstance().removeValue(req, "USERMODEL");
            resp.sendRedirect(req.getContextPath() + "/home");
        } else {
            RequestDispatcher rd = req.getRequestDispatcher("/views/client/home.jsp");
            rd.forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        if (action != null && action.equals("login")) {
            UserModel userModel = FormUtil.toModel(UserModel.class, req);
            userModel = userService.login(userModel.getUserName(), userModel.getPassword(), 1);

            if (userModel != null) {
                SessionUtil.getInstance().putValue(req, "USERMODEL", userModel);

                if (userModel.getRole().equals("user")) {
                    resp.sendRedirect(req.getContextPath() + "/");
                } else if (userModel.getRole().equals("admin")) {
                    resp.sendRedirect(req.getContextPath() + "/admin");
                }
            } else {
                resp.sendRedirect(req.getContextPath() + "/home?action=login&message=info_login_msg");
            }
        }
    }
}
