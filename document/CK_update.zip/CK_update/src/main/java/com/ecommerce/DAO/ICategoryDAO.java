package com.ecommerce.DAO;

import com.ecommerce.model.CategoryModel;
import com.ecommerce.pagination.Pageble;

import java.util.List;

public interface ICategoryDAO extends GenericDAO<CategoryModel> {
    List<CategoryModel> getAll(Pageble pageble);
    int getTotalItem();
}
