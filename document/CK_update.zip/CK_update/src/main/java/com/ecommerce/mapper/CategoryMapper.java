package com.ecommerce.mapper;

import com.ecommerce.model.CategoryModel;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CategoryMapper implements RowMapper<CategoryModel> {
    @Override
    public CategoryModel mapRow(ResultSet resultSet) {
        try {
            CategoryModel category = new CategoryModel();
            category.setId(resultSet.getLong("id"));
            category.setName(resultSet.getString("name"));
            category.setSlug(resultSet.getString("slug"));
            category.setCreatedAt(resultSet.getTimestamp("created_at"));

            if (resultSet.getTimestamp("updated_at") != null) {
                category.setUpdatedAt(resultSet.getTimestamp("updated_at"));
            }
            return category;
        } catch (SQLException e) {
            return null;
        }
    }
}
